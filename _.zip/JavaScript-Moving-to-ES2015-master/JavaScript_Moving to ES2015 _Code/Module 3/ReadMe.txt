Chapter 7 dosen't contain any code because it explains about the functional reactive programming (FRP) using Bacon.js.

Chapter 14 doesn't conatain any code because it explains how to make Node.js applications more secure and how to scale those applications.