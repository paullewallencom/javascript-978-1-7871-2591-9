class Axe{
  constructor(public handleLength, public headHeight){}
}
