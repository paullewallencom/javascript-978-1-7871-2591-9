class PageModel{
  titleVisible: boolean;
  users: Array<User>;
}

class User{}
