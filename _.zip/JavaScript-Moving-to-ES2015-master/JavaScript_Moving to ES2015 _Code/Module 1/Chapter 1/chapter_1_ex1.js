function sayHello(what) {
     return "Hello " + what;
}
console.log(sayHello("world"));