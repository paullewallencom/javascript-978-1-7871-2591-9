//Run this only on BabelJS REPL - https://babeljs.io/repl/
var quote =
   `Good night, good night!
   Parting is such sweet sorrow,
   that I shall say good night
   till it be morrow.`;
console.log( quote );

function sum(a,b){
 console.log(`The sum seems to be ${a + b}`);
}
sum(1,2); //The sum seems to be 3
